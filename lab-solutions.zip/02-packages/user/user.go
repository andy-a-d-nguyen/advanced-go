package user

type User struct {
	Username string
}
